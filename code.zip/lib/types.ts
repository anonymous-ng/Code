export interface Label {
  id: string
  name: string
  slug: string
  description: string | null
  created_at: string
}

export interface Question {
  id: string
  question_text: string
  correct_answer: string
  wrong_answers: string[]
  explanation: string
  additional_info: string | null
  label_id: string
  created_at: string
  labels?: Label
}

export interface QuestionWithLabel extends Question {
  labels: Label
}
