-- Create labels table for question categories
create table if not exists public.labels (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  description text,
  created_at timestamp with time zone default now()
);

-- Create questions table
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  question_text text not null,
  correct_answer text not null,
  wrong_answers text[] not null,
  explanation text not null,
  additional_info text,
  label_id uuid references public.labels(id) on delete cascade,
  created_at timestamp with time zone default now()
);

-- Enable RLS on both tables (public read access for quiz app)
alter table public.labels enable row level security;
alter table public.questions enable row level security;

-- Allow anyone to read labels and questions (public quiz app)
create policy "labels_select_all"
  on public.labels for select
  using (true);

create policy "questions_select_all"
  on public.questions for select
  using (true);

-- Create indexes for better performance
create index if not exists idx_questions_label_id on public.questions(label_id);
create index if not exists idx_labels_slug on public.labels(slug);
