-- Insert sample labels
insert into public.labels (name, slug, description) values
  ('Mathematics', 'mathematics', 'Math problems and equations'),
  ('Science', 'science', 'General science questions'),
  ('History', 'history', 'Historical events and facts'),
  ('Geography', 'geography', 'World geography and locations'),
  ('Literature', 'literature', 'Books, authors, and literary works')
on conflict (slug) do nothing;

-- Insert sample questions for Mathematics
insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'What is 15 × 8?',
  '120',
  array['115', '125', '130'],
  'To multiply 15 by 8, you can break it down: (10 × 8) + (5 × 8) = 80 + 40 = 120',
  'Multiplication is one of the four basic arithmetic operations. Breaking down numbers into tens and ones can make mental math easier.',
  id
from public.labels where slug = 'mathematics'
on conflict do nothing;

insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'What is the square root of 144?',
  '12',
  array['10', '14', '16'],
  'The square root of 144 is 12 because 12 × 12 = 144',
  'A square root is a number that, when multiplied by itself, gives the original number. Perfect squares like 144 have whole number square roots.',
  id
from public.labels where slug = 'mathematics'
on conflict do nothing;

-- Insert sample questions for Science
insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'What is the chemical symbol for gold?',
  'Au',
  array['Go', 'Gd', 'Ag'],
  'The symbol Au comes from the Latin word "aurum" meaning gold',
  'Gold is element 79 on the periodic table. Its Latin name "aurum" reflects its historical importance and value.',
  id
from public.labels where slug = 'science'
on conflict do nothing;

insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'How many planets are in our solar system?',
  '8',
  array['7', '9', '10'],
  'There are 8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune. Pluto was reclassified as a dwarf planet in 2006.',
  'The International Astronomical Union defined the criteria for planets in 2006, which led to Pluto being reclassified as a dwarf planet.',
  id
from public.labels where slug = 'science'
on conflict do nothing;

-- Insert sample questions for History
insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'In which year did World War II end?',
  '1945',
  array['1944', '1946', '1943'],
  'World War II ended in 1945 with Germany surrendering in May and Japan in September after the atomic bombings',
  'The war in Europe ended on May 8, 1945 (V-E Day), and the war in the Pacific ended on September 2, 1945 (V-J Day).',
  id
from public.labels where slug = 'history'
on conflict do nothing;

-- Insert sample questions for Geography
insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'What is the capital of Australia?',
  'Canberra',
  array['Sydney', 'Melbourne', 'Brisbane'],
  'Canberra is the capital of Australia, chosen as a compromise between Sydney and Melbourne',
  'Canberra was purpose-built as the capital in 1913. Many people mistakenly think Sydney is the capital because it is the largest city.',
  id
from public.labels where slug = 'geography'
on conflict do nothing;

-- Insert sample questions for Literature
insert into public.questions (question_text, correct_answer, wrong_answers, explanation, additional_info, label_id)
select 
  'Who wrote "Romeo and Juliet"?',
  'William Shakespeare',
  array['Charles Dickens', 'Jane Austen', 'Mark Twain'],
  'William Shakespeare wrote Romeo and Juliet around 1594-1596. It is one of his most famous tragedies.',
  'Romeo and Juliet is a tragedy about two young star-crossed lovers whose deaths ultimately reconcile their feuding families.',
  id
from public.labels where slug = 'literature'
on conflict do nothing;
